<?php
global $_thd_modules; 

$_thd_modules = array(
		
	);
?>