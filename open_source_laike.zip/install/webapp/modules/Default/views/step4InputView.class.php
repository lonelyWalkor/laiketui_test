<?php

class step4InputView extends SmartyView
{

    public function execute ()
    {

        // set our template
        $this->setTemplate('step4.tpl');

    }

}

?>